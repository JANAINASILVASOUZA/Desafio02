import EntradaInformacoes.entradaInformacoes

fun main() {

   entradaInformacoes()

}